def spacer(size=20, returning=False):
    if returning:
        return size*"──"
    print(size*"──")