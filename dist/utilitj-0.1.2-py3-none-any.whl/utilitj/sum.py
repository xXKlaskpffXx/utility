def sum(list: [int]) -> int:
    y = 0
    for x in list:
        y += x
    return y