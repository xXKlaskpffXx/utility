def avg(list: [int]) -> float:
    y = 0
    for x in list:
        y += x
    return y/len(list)